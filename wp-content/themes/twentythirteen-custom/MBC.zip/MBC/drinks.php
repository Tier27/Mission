<?php $pagename='drinks'; ?>
<?php $tagline='Drinks'; ?>
<?php include("M.php"); ?>
