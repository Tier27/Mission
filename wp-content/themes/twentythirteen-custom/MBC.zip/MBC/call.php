<!DOCTYPE HTML>
<html>
<head>
  <link type="text/css" rel="stylesheet" href="call.css">
  <title>Mission Bowling Club</title>
</head>
<body>
<div class="clear"></div>

<div id="calendar-page">


<div id="page-subheader">
	



<div class="accordion">
<div>
            <input id="ac-1" name="accordion-1" type="checkbox" />
            <label for="ac-1">SOUL & BOWL</label>
<div class="article ac-small">
<P>MBC's Soul Music Curation Series, every 1st and 3rd Monday from 7pm-11pm. We've partnered with guest bartender Daniel Hyatt (formerly of The Alembic) to offer specialty cocktails, paired with free shoe rentals and the hottest tracks to get down to!</p> 
</div>
</div>
<div>
            <input id="ac-2" name="accordion-1" type="checkbox" />
            <label for="ac-2">LEAGUES</label>
<div class="article ac-small">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</div>
</div>
<div>
            <input id="ac-3" name="accordion-1" type="checkbox" />
            <label for="ac-3">GAY BOWLING</label>
<div class="article ac-small">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<div>
</div>
</div>
</div>
</div>


</div>
</div>
</body>
</html>
