<head>
  <link type="text/css" rel="stylesheet" href="css/header.css">
  <link type="text/css" rel="stylesheet" href="css/style.css">
  <meta charset='utf-8'> 
  <title>Mission Bowling Club</title>
  <script src="js/jquery.min.js"></script>
</head>
<?php require_once("imagene/functions.php"); ?>
<?php $pages = get_set_children_names(get_set_id('pages')); ?>
<body>

