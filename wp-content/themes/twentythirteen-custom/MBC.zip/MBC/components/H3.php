    <div class="clear"></div>
    <div id="header-container">
    <div id="header-nav">
        <ul>
            <a href="bowling.php"><li class="indent-0"><span>Bowling</span></li></a>
            <a href="menu.php"><li class="indent-1"><span>Dinner</span></li></a>
            <a href="menu.php"><li class="indent-2"><span>Brunch</span></li></a>
            <a href="menu.php"><li class="indent-3"><span>Drinks</span></li></a>
            <a href="calendar.php"><li class="indent-2"><span>Calendar</span></li></a>
            <a href="event.php"><li class="indent-1"><span>Plan an Event</span></li></a>
            <a href="about.php"><li class="indent-0"><span>About MBC</span></li></a>
        </ul>
    
    </div>
    <div id="header-logo">
        <a href="index.php"><img src="img/logo.png"></a>
    </div>
    <div id="header-address-hours" class="header-banner">
        <p>3176 17th St (@ S. Van Ness)</p>
        <p>San Francisco, CA 94110</p>
        <p>415.863.BOWL (2695)</p><br>
        <p class="header-important">Under 21: Weekends 11-7pm</p>
        <p class="header-small">Monday - Wednesday: 3pm - 11pm</p>
        <p class="header-small">Thursday & Friday: 3pm - Midnight</p>
        <p class="header-small">Saturday:11am - Midnight</p>
        <p class="header-small">Sunday:11am - 11pm</p>
    </div>
    </div>
    <div class="clear"></div>
    <div id="mbc-logo-bottom">
    </div>
<div class="clear"></div>
