<?php $pagename='dinner'; ?>
<?php $tagline='The Dining Room at MBC'; ?>
<?php include("M.php"); ?>
